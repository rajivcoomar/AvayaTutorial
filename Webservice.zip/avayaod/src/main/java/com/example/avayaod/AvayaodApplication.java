package com.example.avayaod;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AvayaodApplication {

	public static void main(String[] args) {
		SpringApplication.run(AvayaodApplication.class, args);
	}

}
